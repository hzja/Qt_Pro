#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_1_clicked()
{
    ui->custom_plot->clearItems();
    ui->custom_plot->clearGraphs();
    ui->custom_plot->clearPlottables();
    ui->custom_plot->plotLayout()->clear();
    ui->custom_plot->replot();
    QCPAxisRect *cs_axis_rect = new QCPAxisRect(ui->custom_plot), *vol_axis_rect = new QCPAxisRect(ui->custom_plot);
    ui->custom_plot->plotLayout()->addElement(0, 0, cs_axis_rect);
    ui->custom_plot->plotLayout()->addElement(1, 0, vol_axis_rect);
    vol_axis_rect->setMaximumSize(QSize(QWIDGETSIZE_MAX, 100));
    for(QCPAxis *axis : cs_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }
    for(QCPAxis *axis : vol_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }

    QCPFinancial *candle_stick = new QCPFinancial(cs_axis_rect->axis(QCPAxis::atBottom), cs_axis_rect->axis(QCPAxis::atLeft));
    QCPBars *volume_pos = new QCPBars(vol_axis_rect->axis(QCPAxis::atBottom), vol_axis_rect->axis(QCPAxis::atLeft));
    QCPBars *volume_neg = new QCPBars(vol_axis_rect->axis(QCPAxis::atBottom), vol_axis_rect->axis(QCPAxis::atLeft));
    QCPDataContainer<QCPFinancialData> QCP_financial_data;
    QSharedPointer<QCPAxisTickerText> text_ticker(new QCPAxisTickerText);

    // 替换为你读取到的数据
    QDateTime currentDateTime = QDateTime::currentDateTime();
    qint64 seed = currentDateTime.toMSecsSinceEpoch();
    QRandomGenerator generator(seed);
    for (int i=1; i<=31; i++) {
        QCPFinancialData data;
        data.key = i;
        data.open = generator.generateDouble()*10;
        data.close = generator.generateDouble()*10;
        data.high = std::max(data.open, data.close) + generator.generateDouble();
        data.low = std::min(data.open, data.close) - generator.generateDouble();
        qDebug() << data.open << data.close << data.high << data.low;
        QCP_financial_data.add(data);

        (i % 2 ? volume_neg : volume_pos)->addData(data.key, generator.generateDouble()*10);
        text_ticker->addTick(data.key, QString::fromStdString(std::to_string(i)));
    }

    candle_stick->setName("日K");
    candle_stick->setChartStyle(QCPFinancial::csCandlestick);
    candle_stick->setBrushPositive(QColor("#EC0000"));
    candle_stick->setBrushNegative(QColor("#00DA3C"));
    candle_stick->setPenPositive(QColor("#8A0000"));
    candle_stick->setPenNegative(QColor("#008F28"));
    candle_stick->data()->set(QCP_financial_data);
    volume_pos->setPen(Qt::NoPen);
    volume_pos->setBrush(QColor("#EC0000"));
    volume_neg->setPen(Qt::NoPen);
    volume_neg->setBrush(QColor("#00DA3C"));

    connect(cs_axis_rect->axis(QCPAxis::atBottom), SIGNAL(rangeChanged(QCPRange)), vol_axis_rect->axis(QCPAxis::atBottom), SLOT(setRange(QCPRange)));
    connect(vol_axis_rect->axis(QCPAxis::atBottom), SIGNAL(rangeChanged(QCPRange)), cs_axis_rect->axis(QCPAxis::atBottom), SLOT(setRange(QCPRange)));

    vol_axis_rect->axis(QCPAxis::atBottom)->setTicker(text_ticker);
    vol_axis_rect->axis(QCPAxis::atBottom)->setTickLabelRotation(15);
    cs_axis_rect->axis(QCPAxis::atBottom)->setBasePen(Qt::NoPen);
    cs_axis_rect->axis(QCPAxis::atBottom)->setTickLabels(false);
    cs_axis_rect->axis(QCPAxis::atBottom)->setTicks(false);

    ui->custom_plot->rescaleAxes();
    cs_axis_rect->axis(QCPAxis::atBottom)->setRange(0, 32);

    QCPMarginGroup *group = new QCPMarginGroup(ui->custom_plot);
    ui->custom_plot->axisRect()->setMarginGroup(QCP::msLeft|QCP::msRight, group);
    cs_axis_rect->setMarginGroup(QCP::msLeft|QCP::msRight, group);
    vol_axis_rect->setMarginGroup(QCP::msLeft|QCP::msRight, group);

    ui->custom_plot->replot();
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->custom_plot->clearItems();
    ui->custom_plot->clearGraphs();
    ui->custom_plot->clearPlottables();
    ui->custom_plot->plotLayout()->clear();
    ui->custom_plot->replot();

    QCPAxisRect *axis_rect = new QCPAxisRect(ui->custom_plot);
    ui->custom_plot->plotLayout()->addElement(0, 0, axis_rect);
    QCPColorMap *color_map = new QCPColorMap(axis_rect->axis(QCPAxis::atBottom), axis_rect->axis(QCPAxis::atLeft));
    QSharedPointer<QCPAxisTickerText> text_ticker(new QCPAxisTickerText);

    int k = 10;
    color_map->data()->setSize(k, k);
    color_map->data()->setRange(QCPRange(0, k-1), QCPRange(0, k-1));

    QDateTime currentDateTime = QDateTime::currentDateTime();
    qint64 seed = currentDateTime.toMSecsSinceEpoch();
    QRandomGenerator generator(seed);
    for (int i=0; i<k; i++) {
        for (int j=0; j<k; j++) {
            double correlation = generator.generateDouble() * 2 - 1;
            color_map->data()->setCell(i, j, correlation);
            QCPItemText *textLabel = new QCPItemText(ui->custom_plot);
            if (correlation > 0) textLabel->setColor(Qt::white);
            else textLabel->setColor(Qt::black);
            textLabel->setPositionAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
            textLabel->position->setAxes(axis_rect->axis(QCPAxis::atBottom), axis_rect->axis(QCPAxis::atLeft));
            textLabel->position->setAxisRect(axis_rect);
            textLabel->setClipToAxisRect(true);
            textLabel->position->setCoords(i, j); // 设置位置
            textLabel->setText(QString::number(correlation)); // 显示数值
        }
        text_ticker->addTick(i, QString::fromStdString(std::to_string(i)));
    }

    axis_rect->axis(QCPAxis::atLeft)->setTicker(text_ticker);
    axis_rect->axis(QCPAxis::atBottom)->setTicker(text_ticker);
    axis_rect->axis(QCPAxis::atBottom)->setTickLabelRotation(15);
    axis_rect->axis(QCPAxis::atLeft)->setTickLength(0);
    axis_rect->axis(QCPAxis::atBottom)->setTickLength(0);
    axis_rect->axis(QCPAxis::atLeft)->grid()->setPen(Qt::NoPen);
    axis_rect->axis(QCPAxis::atBottom)->grid()->setPen(Qt::NoPen);
    axis_rect->axis(QCPAxis::atLeft)->grid()->setZeroLinePen(Qt::NoPen);
    axis_rect->axis(QCPAxis::atBottom)->grid()->setZeroLinePen(Qt::NoPen);
    axis_rect->axis(QCPAxis::atLeft)->setRange(-0.5, k-0.5);
    axis_rect->axis(QCPAxis::atBottom)->setRange(-0.5, k-0.5);

    QCPColorScale *color_scale = new QCPColorScale(ui->custom_plot);
    ui->custom_plot->plotLayout()->addElement(0, 1, color_scale);
    color_scale->setType(QCPAxis::atRight);
    color_scale->setDataRange(QCPRange(-1.0, 1.0));
    color_map->setColorScale(color_scale);
    QCPColorGradient gradient;
    gradient.setColorStopAt(0.0, QColor("#ffffd0"));
    gradient.setColorStopAt(0.5, QColor("#3eb6c5"));
    gradient.setColorStopAt(1.0, QColor("#042060"));
    color_map->setGradient(gradient);
    color_map->setInterpolate(false);
    ui->custom_plot->replot();
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->custom_plot->clearItems();
    ui->custom_plot->clearGraphs();
    ui->custom_plot->clearPlottables();
    ui->custom_plot->plotLayout()->clear();
    ui->custom_plot->replot();
    QCPAxisRect *last_axis_rect = new QCPAxisRect(ui->custom_plot), *next_axis_rect = new QCPAxisRect(ui->custom_plot);
    ui->custom_plot->plotLayout()->addElement(0, 0, last_axis_rect);
    ui->custom_plot->plotLayout()->addElement(0, 1, next_axis_rect);
    QCPGraph *last_line_plot = new QCPGraph(last_axis_rect->axis(QCPAxis::atBottom), last_axis_rect->axis(QCPAxis::atLeft));
    QCPGraph *next_target_line_plot = new QCPGraph(next_axis_rect->axis(QCPAxis::atBottom), next_axis_rect->axis(QCPAxis::atLeft));
    QCPGraph *next_predict_line_plot = new QCPGraph(next_axis_rect->axis(QCPAxis::atBottom), next_axis_rect->axis(QCPAxis::atLeft));
    last_line_plot->setPen(QPen(Qt::red));
    next_target_line_plot->setPen(QPen(Qt::red));
    next_predict_line_plot->setPen(QPen(Qt::green));

    QDateTime currentDateTime = QDateTime::currentDateTime();
    qint64 seed = currentDateTime.toMSecsSinceEpoch();
    QRandomGenerator generator(seed);
    for (int i=1; i<=31; i++) {
        last_line_plot->addData(i, generator.generateDouble()*10);
        next_target_line_plot->addData(i, generator.generateDouble()*10);
        next_predict_line_plot->addData(i, generator.generateDouble()*10);
    }

    for(QCPAxis *axis : last_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }
    for(QCPAxis *axis : next_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }
    ui->custom_plot->rescaleAxes();
    last_axis_rect->axis(QCPAxis::atBottom)->setRange(0, 32);
    next_axis_rect->axis(QCPAxis::atBottom)->setRange(0, 32);

    ui->custom_plot->replot();
}

